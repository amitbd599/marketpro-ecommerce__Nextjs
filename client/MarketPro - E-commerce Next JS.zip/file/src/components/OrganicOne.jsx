"use client";

import React, { useRef } from "react";
import Link from "next/link";
import Slider from "react-slick";

const OrganicOne = () => {
  const sliderRef = useRef(null);

  const settings = {
    dots: false,
    arrows: false,
    infinite: true,
    speed: 1000,
    slidesToShow: 6,
    slidesToScroll: 1,
    initialSlide: 0,
    autoplay: true,
    responsive: [
      {
        breakpoint: 1599,
        settings: {
          slidesToShow: 6,
        },
      },
      {
        breakpoint: 1399,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 575,
        settings: {
          slidesToShow: 1,
        },
      },
      {
        breakpoint: 424,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };
  return (
    <section className='organic-food py-80'>
      <div className='container container-lg'>
        <div className='section-heading'>
          <div className='flex-between flex-wrap gap-8'>
            <h5 className='mb-0'>Organic Food</h5>
            <div className='inner flex-align  gap-16'>
              <Link
                href='/shop'
                className='text-sm fw-medium text-gray-700 hover-text-main-600 hover-text-decoration-underline'
              >
                All Categories
              </Link>
              <div className='flex-align gap-8'>
                <button
                  onClick={() => sliderRef.current.slickPrev()}
                  type='button'
                  id='organic-prev'
                  className='slick-prev slick-arrow flex-center rounded-circle border border-gray-100 hover-border-main-600 text-xl hover-bg-main-600 hover-text-white transition-1'
                >
                  <i className='ph ph-caret-left' />
                </button>
                <button
                  onClick={() => sliderRef.current.slickNext()}
                  type='button'
                  id='organic-next'
                  className='slick-next slick-arrow flex-center rounded-circle border border-gray-100 hover-border-main-600 text-xl hover-bg-main-600 hover-text-white transition-1'
                >
                  <i className='ph ph-caret-right' />
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className='organic-food__slider arrow-style-two'>
          <Slider ref={sliderRef} {...settings}>
            <div>
              <div className='product-card px-8 py-16 border border-gray-100 hover-border-main-600 rounded-16 position-relative transition-2'>
                <Link
                  href='/product-details'
                  className='product-card__thumb flex-center'
                >
                  <img
                    src='assets/images/thumbs/product-img20.png'
                    alt='marketpro'
                  />
                </Link>
                <div className='product-card__content mt-12'>
                  <div className='flex-align gap-6'>
                    <span className='text-xs fw-bold text-gray-500'>4.8</span>
                    <span className='text-15 fw-bold text-warning-600 d-flex'>
                      <i className='ph-fill ph-star' />
                    </span>
                    <span className='text-xs fw-bold text-gray-500'>(17k)</span>
                  </div>
                  <h6 className='title text-lg fw-semibold mt-12 mb-8'>
                    <Link href='/product-details' className='link text-line-2'>
                      Taylor Farms Broccoli Florets Vegetables
                    </Link>
                  </h6>
                  <div className='flex-align gap-4'>
                    <span className='text-main-600 text-md d-flex'>
                      <i className='ph-fill ph-storefront' />
                    </span>
                    <span className='text-gray-500 text-xs'>
                      By Lucky Supermarket
                    </span>
                  </div>
                  <div className='flex-between gap-8 mt-24 flex-wrap'>
                    <div className='product-card__price'>
                      <span className='text-gray-400 text-md fw-semibold text-decoration-line-through d-block'>
                        $28.99
                      </span>
                      <span className='text-heading text-md fw-semibold '>
                        $14.99{" "}
                        <span className='text-gray-500 fw-normal'>/Qty</span>{" "}
                      </span>
                    </div>
                    <Link
                      href='/cart'
                      className='product-card__cart btn bg-main-50 text-main-600 hover-bg-main-600 hover-text-white py-11 px-24 rounded-pill flex-align gap-8'
                    >
                      Add <i className='ph ph-shopping-cart' />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='product-card px-8 py-16 border border-gray-100 hover-border-main-600 rounded-16 position-relative transition-2'>
                <Link
                  href='/product-details'
                  className='product-card__thumb flex-center'
                >
                  <img
                    src='assets/images/thumbs/product-img21.png'
                    alt='marketpro'
                  />
                </Link>
                <div className='product-card__content mt-12'>
                  <div className='flex-align gap-6'>
                    <span className='text-xs fw-bold text-gray-500'>4.8</span>
                    <span className='text-15 fw-bold text-warning-600 d-flex'>
                      <i className='ph-fill ph-star' />
                    </span>
                    <span className='text-xs fw-bold text-gray-500'>(17k)</span>
                  </div>
                  <h6 className='title text-lg fw-semibold mt-12 mb-8'>
                    <Link href='/product-details' className='link text-line-2'>
                      Taylor Farms Broccoli Florets Vegetables
                    </Link>
                  </h6>
                  <div className='flex-align gap-4'>
                    <span className='text-main-600 text-md d-flex'>
                      <i className='ph-fill ph-storefront' />
                    </span>
                    <span className='text-gray-500 text-xs'>
                      By Lucky Supermarket
                    </span>
                  </div>
                  <div className='flex-between gap-8 mt-24 flex-wrap'>
                    <div className='product-card__price'>
                      <span className='text-gray-400 text-md fw-semibold text-decoration-line-through d-block'>
                        $28.99
                      </span>
                      <span className='text-heading text-md fw-semibold '>
                        $14.99{" "}
                        <span className='text-gray-500 fw-normal'>/Qty</span>{" "}
                      </span>
                    </div>
                    <Link
                      href='/cart'
                      className='product-card__cart btn bg-main-50 text-main-600 hover-bg-main-600 hover-text-white py-11 px-24 rounded-pill flex-align gap-8'
                    >
                      Add <i className='ph ph-shopping-cart' />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='product-card px-8 py-16 border border-gray-100 hover-border-main-600 rounded-16 position-relative transition-2'>
                <Link
                  href='/product-details'
                  className='product-card__thumb flex-center'
                >
                  <img
                    src='assets/images/thumbs/product-img22.png'
                    alt='marketpro'
                  />
                </Link>
                <div className='product-card__content mt-12'>
                  <div className='flex-align gap-6'>
                    <span className='text-xs fw-bold text-gray-500'>4.8</span>
                    <span className='text-15 fw-bold text-warning-600 d-flex'>
                      <i className='ph-fill ph-star' />
                    </span>
                    <span className='text-xs fw-bold text-gray-500'>(17k)</span>
                  </div>
                  <h6 className='title text-lg fw-semibold mt-12 mb-8'>
                    <Link href='/product-details' className='link text-line-2'>
                      Taylor Farms Broccoli Florets Vegetables
                    </Link>
                  </h6>
                  <div className='flex-align gap-4'>
                    <span className='text-main-600 text-md d-flex'>
                      <i className='ph-fill ph-storefront' />
                    </span>
                    <span className='text-gray-500 text-xs'>
                      By Lucky Supermarket
                    </span>
                  </div>
                  <div className='flex-between gap-8 mt-24 flex-wrap'>
                    <div className='product-card__price'>
                      <span className='text-gray-400 text-md fw-semibold text-decoration-line-through d-block'>
                        $28.99
                      </span>
                      <span className='text-heading text-md fw-semibold '>
                        $14.99{" "}
                        <span className='text-gray-500 fw-normal'>/Qty</span>{" "}
                      </span>
                    </div>
                    <Link
                      href='/cart'
                      className='product-card__cart btn bg-main-50 text-main-600 hover-bg-main-600 hover-text-white py-11 px-24 rounded-pill flex-align gap-8'
                    >
                      Add <i className='ph ph-shopping-cart' />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='product-card px-8 py-16 border border-gray-100 hover-border-main-600 rounded-16 position-relative transition-2'>
                <Link
                  href='/product-details'
                  className='product-card__thumb flex-center'
                >
                  <img
                    src='assets/images/thumbs/product-img23.png'
                    alt='marketpro'
                  />
                </Link>
                <div className='product-card__content mt-12'>
                  <div className='flex-align gap-6'>
                    <span className='text-xs fw-bold text-gray-500'>4.8</span>
                    <span className='text-15 fw-bold text-warning-600 d-flex'>
                      <i className='ph-fill ph-star' />
                    </span>
                    <span className='text-xs fw-bold text-gray-500'>(17k)</span>
                  </div>
                  <h6 className='title text-lg fw-semibold mt-12 mb-8'>
                    <Link href='/product-details' className='link text-line-2'>
                      Taylor Farms Broccoli Florets Vegetables
                    </Link>
                  </h6>
                  <div className='flex-align gap-4'>
                    <span className='text-main-600 text-md d-flex'>
                      <i className='ph-fill ph-storefront' />
                    </span>
                    <span className='text-gray-500 text-xs'>
                      By Lucky Supermarket
                    </span>
                  </div>
                  <div className='flex-between gap-8 mt-24 flex-wrap'>
                    <div className='product-card__price'>
                      <span className='text-gray-400 text-md fw-semibold text-decoration-line-through d-block'>
                        $28.99
                      </span>
                      <span className='text-heading text-md fw-semibold '>
                        $14.99{" "}
                        <span className='text-gray-500 fw-normal'>/Qty</span>{" "}
                      </span>
                    </div>
                    <Link
                      href='/cart'
                      className='product-card__cart btn bg-main-50 text-main-600 hover-bg-main-600 hover-text-white py-11 px-24 rounded-pill flex-align gap-8'
                    >
                      Add <i className='ph ph-shopping-cart' />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='product-card px-8 py-16 border border-gray-100 hover-border-main-600 rounded-16 position-relative transition-2'>
                <Link
                  href='/product-details'
                  className='product-card__thumb flex-center'
                >
                  <img
                    src='assets/images/thumbs/product-img24.png'
                    alt='marketpro'
                  />
                </Link>
                <div className='product-card__content mt-12'>
                  <div className='flex-align gap-6'>
                    <span className='text-xs fw-bold text-gray-500'>4.8</span>
                    <span className='text-15 fw-bold text-warning-600 d-flex'>
                      <i className='ph-fill ph-star' />
                    </span>
                    <span className='text-xs fw-bold text-gray-500'>(17k)</span>
                  </div>
                  <h6 className='title text-lg fw-semibold mt-12 mb-8'>
                    <Link href='/product-details' className='link text-line-2'>
                      Taylor Farms Broccoli Florets Vegetables
                    </Link>
                  </h6>
                  <div className='flex-align gap-4'>
                    <span className='text-main-600 text-md d-flex'>
                      <i className='ph-fill ph-storefront' />
                    </span>
                    <span className='text-gray-500 text-xs'>
                      By Lucky Supermarket
                    </span>
                  </div>
                  <div className='flex-between gap-8 mt-24 flex-wrap'>
                    <div className='product-card__price'>
                      <span className='text-gray-400 text-md fw-semibold text-decoration-line-through d-block'>
                        $28.99
                      </span>
                      <span className='text-heading text-md fw-semibold '>
                        $14.99{" "}
                        <span className='text-gray-500 fw-normal'>/Qty</span>{" "}
                      </span>
                    </div>
                    <Link
                      href='/cart'
                      className='product-card__cart btn bg-main-50 text-main-600 hover-bg-main-600 hover-text-white py-11 px-24 rounded-pill flex-align gap-8'
                    >
                      Add <i className='ph ph-shopping-cart' />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='product-card px-8 py-16 border border-gray-100 hover-border-main-600 rounded-16 position-relative transition-2'>
                <Link
                  href='/product-details'
                  className='product-card__thumb flex-center'
                >
                  <img
                    src='assets/images/thumbs/product-img25.png'
                    alt='marketpro'
                  />
                </Link>
                <div className='product-card__content mt-12'>
                  <div className='flex-align gap-6'>
                    <span className='text-xs fw-bold text-gray-500'>4.8</span>
                    <span className='text-15 fw-bold text-warning-600 d-flex'>
                      <i className='ph-fill ph-star' />
                    </span>
                    <span className='text-xs fw-bold text-gray-500'>(17k)</span>
                  </div>
                  <h6 className='title text-lg fw-semibold mt-12 mb-8'>
                    <Link href='/product-details' className='link text-line-2'>
                      Taylor Farms Broccoli Florets Vegetables
                    </Link>
                  </h6>
                  <div className='flex-align gap-4'>
                    <span className='text-main-600 text-md d-flex'>
                      <i className='ph-fill ph-storefront' />
                    </span>
                    <span className='text-gray-500 text-xs'>
                      By Lucky Supermarket
                    </span>
                  </div>
                  <div className='flex-between gap-8 mt-24 flex-wrap'>
                    <div className='product-card__price'>
                      <span className='text-gray-400 text-md fw-semibold text-decoration-line-through d-block'>
                        $28.99
                      </span>
                      <span className='text-heading text-md fw-semibold '>
                        $14.99{" "}
                        <span className='text-gray-500 fw-normal'>/Qty</span>{" "}
                      </span>
                    </div>
                    <Link
                      href='/cart'
                      className='product-card__cart btn bg-main-50 text-main-600 hover-bg-main-600 hover-text-white py-11 px-24 rounded-pill flex-align gap-8'
                    >
                      Add <i className='ph ph-shopping-cart' />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='product-card px-8 py-16 border border-gray-100 hover-border-main-600 rounded-16 position-relative transition-2'>
                <Link
                  href='/product-details'
                  className='product-card__thumb flex-center'
                >
                  <img
                    src='assets/images/thumbs/product-img21.png'
                    alt='marketpro'
                  />
                </Link>
                <div className='product-card__content mt-12'>
                  <div className='flex-align gap-6'>
                    <span className='text-xs fw-bold text-gray-500'>4.8</span>
                    <span className='text-15 fw-bold text-warning-600 d-flex'>
                      <i className='ph-fill ph-star' />
                    </span>
                    <span className='text-xs fw-bold text-gray-500'>(17k)</span>
                  </div>
                  <h6 className='title text-lg fw-semibold mt-12 mb-8'>
                    <Link href='/product-details' className='link text-line-2'>
                      Taylor Farms Broccoli Florets Vegetables
                    </Link>
                  </h6>
                  <div className='flex-align gap-4'>
                    <span className='text-main-600 text-md d-flex'>
                      <i className='ph-fill ph-storefront' />
                    </span>
                    <span className='text-gray-500 text-xs'>
                      By Lucky Supermarket
                    </span>
                  </div>
                  <div className='flex-between gap-8 mt-24 flex-wrap'>
                    <div className='product-card__price'>
                      <span className='text-gray-400 text-md fw-semibold text-decoration-line-through d-block'>
                        $28.99
                      </span>
                      <span className='text-heading text-md fw-semibold '>
                        $14.99{" "}
                        <span className='text-gray-500 fw-normal'>/Qty</span>{" "}
                      </span>
                    </div>
                    <Link
                      href='/cart'
                      className='product-card__cart btn bg-main-50 text-main-600 hover-bg-main-600 hover-text-white py-11 px-24 rounded-pill flex-align gap-8'
                    >
                      Add <i className='ph ph-shopping-cart' />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </Slider>
        </div>
      </div>
    </section>
  );
};

export default OrganicOne;
